Палитра Группы «Эталон».

Cards/ — карточка каждого цвета (SVG, PNG, PDF) с кодами HEX, RGB, CMYK, Pantone и RAL.
Etalon_Palette — вся палитра одним листом (SVG, PNG, PDF).
Etalon_Palette.ase — образцы для Adobe Photoshop, Illustrator и InDesign.
Etalon_Palette.css и .json — значения для разработки.

Фирменный синий #223E90 — основной цвет. Оранжевый используется только как акцент.
Не изменяйте фирменные цвета.
